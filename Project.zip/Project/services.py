from flask import Flask, jsonify,render_template, send_file
import subprocess,os
import datetime as Dt
from flask_cors import CORS
app=Flask(__name__)

CORS(app)

def whoami():
     command = "whoami"
     return (subprocess.check_output(command, shell=True)).decode()

username=whoami()

def getPath(path='HOME'):
    HomePath=os.environ[path]
    return HomePath

def getTimeAsString(TSec:float) -> str:
    tObj=Dt.datetime.fromtimestamp(TSec)
    tString=Dt.datetime.strftime(tObj,'%Y-%m-%d %H-%M-%S')
    return tString

def getSizeSymbol(num,suffix='B')-> str:
    for i in ['','K','M','G','T']:
        if abs(num) <1024.0:
            return "%3.1f%s%s" % (num,i,suffix)
        num/=1024.0
    return "%.1f%s%s" % (num,'Y',suffix)

def FilesConnected():
    command2="lsof -u {}| cut -f9 | sort -u | wc -l".format(username)
    output = subprocess.check_output(command2, shell=True)
    return output.decode()


def DirectoriesConnected():
    command = "lsof -u {}| cut -f9| grep -o '/[^/]*$' | sort -u | wc -l".format(username)
    output = subprocess.check_output(command, shell=True)
    return output.decode()

def SizeUser():
    username = whoami()
    command = "du -hs /home/{}| cut -f1".format(username)
    output = subprocess.check_output(command, shell=True)
    usage = output.decode().strip()
    return usage


@app.route('/')
def login():
    return render_template('/login.html')

@app.route('/HomePage')
def HomePage():
    return render_template('/index.html')

@app.route('/GetHomeData',methods=['GET'])
def GetHomeData():
    def fObjFromScan(x):
        filestat=x.stat()
        fSize=getSizeSymbol(filestat.st_size)
        fMTime=getTimeAsString(filestat.st_mtime)
        return {'name':x.name, 'size':fSize, 'm_Time':fMTime}

    fNames=[fObjFromScan(x) for x in os.scandir(getPath())]
    return jsonify(items=fNames),200

@app.route('/GetNumberFilesCNX')
def getFilesUserCNX():
    return FilesConnected()

@app.route('/GetNumberDirectoriesCNX')
def getDirectoriesConnected():
    ListUsersCnX=[]
    ListUsersCnX.append(DirectoriesConnected())
    return ListUsersCnX

@app.route('/DirSpace')
def SpaceDir():
    return  SizeUser()

if __name__=='__main__':
    app.run(host='localhost',port=5058)